public interface ILevelFlow
{
    void CompleteLevel();
    void KillPlayer();
    void Reload();
    void LoadNext();
}
